makefile for CppUnit with Borland C++ 5.5 free compiler

instruction:

- copy this directory 'bcc' under <cppunit>-install dir.

- edit <cppunit>/bcc/makefile :
       line 8: BCB=...

- invoke 'make' on <cppunit>/bcc

  cppunit_bc5.lib
  cppunitd_bc5.lib
  cppunit_bc5_dll.dll  cppunit_bc5_dll.lib
  cppunitd_bc5_dll.dll cppunitd_bc5_dll.lib

  will be produced at <cppunit>/bcc .

have fun!

'cuppa' project team (http://sourceforge.jp/projects/cuppa/)
($Date: 2002/04/16 09:44:09 $)
