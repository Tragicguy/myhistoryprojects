//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by vbMHWB.rc
//
#define IDS_PROJNAME                    100
#define IDB_VBWB                        101
#define IDH_VBWB                        102
#define IDR_VBWB                        103
#define IDS_VBURLCOMPONENTS_DESC        104
#define IDR_vbUrlComponents             105
#define IDS_HWND                        105
#define IDR_WBURLCOMPONENTS             106
#define IDS_THREADID                    106
#define IDS_INST_HANDLE                 107
#define IDS_MODULE_PATH                 108
#define IDS_CTL_DESIGNMODE              109
#define IDS_CUR_VERSION                 110
#define IDS_WB_NOT_FOUND                111
#define IDS_WBHOST_NOT_FOUND            112
#define IDS_EXECWB_FAILED               113
#define IDS_QSWB_FAILED                 114
#define IDS_NO_DOCDISPATCH              115
#define IDS_NO_DOCOBJECT                116
#define IDS_NO_ACTIVEELEM               117
#define IDS_WB_CREATE_FAILED            118
#define IDS_HOST_CREATE_FAILED          119
#define IDS_ACCEL_PROP_ERR              120
#define IDS_PROP_VALUE_ERR              121
#define IDS_NO_BROWSEROBJ               122
#define IDS_HTTPS_PROT_REGISTERED       123
#define IDS_HTTP_PROT_REGISTERED        124
#define IDS_NO_DLMANAGER                125
#define IDS_NO_URLMONIKOR               126
#define IDS_NO_ASYNCBINDCTX             127
#define IDS_BINDTOSTORAGE_FAILED        128
#define IDS_SSLCMD_FAILED               129
#define IDS_CONTENTLENZERO_ERR          130
#define IDS_MEMALLOCATION_FAILED        131
#define IDS_NO_IVIEWOBJ                 132
#define IDS_DRAWOP_ABORTED              133
#define IDS_NO_ACTIVEDOC                134
#define IDS_NO_FONTSIZE                 135
#define IDS_NO_FONTSIZE_SET             136
#define IDS_NO_HWND_ERR                 137
#define IDS_NO_SUBCLASS_ERR             138
#define IDS_NO_HWND_SUBCLASSED          139
#define IDS_NO_EDITHWND                 140
#define IDS_SHLWAPI_LOAD_FAILED         141
#define IDS_SHAUTOCOMPLETE_FAILED       142
#define IDS_SHAUTOCOMPLET_CALLFAILED    143
#define IDS_UNABLE_TOSAVE_BMP           144
#define IDS_UNABLE_TOCREATE_CLASS       145
#define IDS_UNABLE_TOINIT_CLASS         146
#define IDS_ERROR_NUMBER                147
#define IDS_UNABLETO_REMOVEWB           148
#define ID_IE_FILE_OPEN                 256
#define ID_IE_FILE_SAVE                 257
#define ID_IE_FILE_SAVEAS               258
#define ID_IE_FILE_NEWMAIL              279
#define ID_IE_FILE_SENDPAGE             282
#define ID_IE_FILE_SENDLINK             283
#define ID_IE_FILE_SENDDESKTOPSHORTCUT  284
#define ID_IE_FILE_IMPORTEXPORT         374
#define ID_IE_FILE_ADDTRUST             376
#define ID_IE_FILE_ADDLOCAL             377
#define ID_IE_FILE_NEWCALL              395
#define ID_IE_CONTEXTMENU_VIEWSOURCE    2139
#define ID_IE_CONTEXTMENU_ADDFAV        2261
#define ID_IE_CONTEXTMENU_REFRESH       6042

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        202
#define _APS_NEXT_COMMAND_VALUE         32768
#define _APS_NEXT_CONTROL_VALUE         201
#define _APS_NEXT_SYMED_VALUE           107
#endif
#endif
