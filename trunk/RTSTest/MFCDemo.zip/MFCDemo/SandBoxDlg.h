//{{AFX_INCLUDES()
#include "vbwb.h"
//}}AFX_INCLUDES
#if !defined(AFX_SANDBOXDLG_H__DCFAE824_B317_40DB_889F_1BC47F89FA4D__INCLUDED_)
#define AFX_SANDBOXDLG_H__DCFAE824_B317_40DB_889F_1BC47F89FA4D__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// SandBoxDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CSandBoxDlg dialog

class CSandBoxDlg : public CDialog
{
// Construction
public:
	short m_CurSandBox;
	CSandBoxDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CSandBoxDlg)
	enum { IDD = IDD_SANDBOX_DLG };
	CvbWB	m_SandBoxWB;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CSandBoxDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CSandBoxDlg)
	afx_msg void OnClose();
	afx_msg void OnWindowClosingVbwb1(short wbUID, BOOL IsChildWindow, BOOL FAR* Cancel);
	afx_msg void OnWindowSetHeightVbwb1(short wbUID, long Height);
	afx_msg void OnWindowSetLeftVbwb1(short wbUID, long Left);
	afx_msg void OnWindowSetTopVbwb1(short wbUID, long Top);
	afx_msg void OnWindowSetWidthVbwb1(short wbUID, long Width);
	afx_msg void OnSize(UINT nType, int cx, int cy);
	DECLARE_EVENTSINK_MAP()
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SANDBOXDLG_H__DCFAE824_B317_40DB_889F_1BC47F89FA4D__INCLUDED_)
