//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by MFCDemo.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_MFCDEMO_DIALOG              102
#define IDR_MAINFRAME                   128
#define IDD_FIND_DLG                    130
#define IDD_SANDBOX_DLG                 132
#define IDC_EDIT1                       1000
#define IDC_BUTTON1                     1001
#define IDC_VBWB1                       1002
#define IDC_EDIT2                       1003
#define IDC_CHKHTTPPROTOCOLS            1005
#define IDC_TXTFIND                     1006
#define IDC_BTNFIND                     1007
#define IDC_CHKFIND_HIGHLIGHT           1009
#define IDC_CHKFIND_MATCHWWORDS         1010
#define IDC_CHKFIND_MATCHCASE           1011
#define IDC_RDFIND_DOWNWARD             1012
#define IDC_RDFIND_UPWARD               1013
#define IDC_COMBFIND_COLORS             1014
#define IDC_BTNSANDBOX                  1016
#define IDC_WB_TABS                     1017
#define IDC_CHKNEWWB                    1018
#define IDC_BACK_BTN                    1023
#define IDC_STOP_BTN                    1024
#define IDC_FORWARD_BTN                 1025
#define IDC_WBCOUNT_STATIC              1026
#define IDC_STATIC_STATUS               1027
#define IDC_BTNTHUMBNAILS               1029
#define IDC_COMBOZOOM                   1030
#define IDC_BUTTONZOOM                  1031
#define IDC_URLCOMBO                    1033
#define IDC_BTN_SAVEASBITMAP            1034
#define IDC_BTN_POSTDATA                1035
#define IDC_CHKSOURCE                   1036

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        135
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1037
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
