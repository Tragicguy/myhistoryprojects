// SandBoxDlg.cpp : implementation file
//

#include "stdafx.h"
#include "MFCDemo.h"
#include "SandBoxDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CSandBoxDlg dialog


CSandBoxDlg::CSandBoxDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CSandBoxDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CSandBoxDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void CSandBoxDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CSandBoxDlg)
	DDX_Control(pDX, IDC_VBWB1, m_SandBoxWB);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CSandBoxDlg, CDialog)
	//{{AFX_MSG_MAP(CSandBoxDlg)
	ON_WM_CLOSE()
	ON_WM_SIZE()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSandBoxDlg message handlers

void CSandBoxDlg::OnClose() 
{
	//CDialog::OnClose();
	//Just hide it, we destroy this wnd in DemoDlg OnClose event
	m_SandBoxWB.NavigateSimple(m_CurSandBox, _T("about:blank"));
	ShowWindow(FALSE);
}


BEGIN_EVENTSINK_MAP(CSandBoxDlg, CDialog)
    //{{AFX_EVENTSINK_MAP(CSandBoxDlg)
	ON_EVENT(CSandBoxDlg, IDC_VBWB1, 16 /* WindowClosing */, OnWindowClosingVbwb1, VTS_I2 VTS_BOOL VTS_PBOOL)
	ON_EVENT(CSandBoxDlg, IDC_VBWB1, 17 /* WindowSetHeight */, OnWindowSetHeightVbwb1, VTS_I2 VTS_I4)
	ON_EVENT(CSandBoxDlg, IDC_VBWB1, 18 /* WindowSetLeft */, OnWindowSetLeftVbwb1, VTS_I2 VTS_I4)
	ON_EVENT(CSandBoxDlg, IDC_VBWB1, 20 /* WindowSetTop */, OnWindowSetTopVbwb1, VTS_I2 VTS_I4)
	ON_EVENT(CSandBoxDlg, IDC_VBWB1, 21 /* WindowSetWidth */, OnWindowSetWidthVbwb1, VTS_I2 VTS_I4)
	//}}AFX_EVENTSINK_MAP
END_EVENTSINK_MAP()

void CSandBoxDlg::OnWindowClosingVbwb1(short wbUID, BOOL IsChildWindow, BOOL FAR* Cancel) 
{
	*Cancel = VARIANT_TRUE;
	OnClose();
}

void CSandBoxDlg::OnWindowSetHeightVbwb1(short wbUID, long Height) 
{
		WINDOWPLACEMENT lpwp;
		lpwp.length = sizeof(WINDOWPLACEMENT);
		GetWindowPlacement(&lpwp);
		if(lpwp.showCmd == SW_SHOWMINIMIZED) //SW_MAXIMIZE
			return;

	if(Height > 0)
	{
		RECT trect;
		GetWindowRect(&trect);
		SetWindowPos(NULL,0,0, trect.right - trect.left ,(int)Height,SWP_NOMOVE); //x, y are ignored
	}
}

void CSandBoxDlg::OnWindowSetLeftVbwb1(short wbUID, long Left) 
{
	if(Left > 0)
	{
		RECT trect;
		GetWindowRect(&trect);
		SetWindowPos(NULL,(int)Left, 0, trect.top , 0,SWP_NOSIZE); //Width, Height are ignored
	}
}

void CSandBoxDlg::OnWindowSetTopVbwb1(short wbUID, long Top) 
{
	if(Top > 0)
	{
		RECT trect;
		GetWindowRect(&trect);
		SetWindowPos(NULL,trect.left ,(int)Top, 0, 0, SWP_NOSIZE);
	}
}

void CSandBoxDlg::OnWindowSetWidthVbwb1(short wbUID, long Width) 
{
	if(Width > 0)
	{
		RECT trect;
		GetWindowRect(&trect);
		SetWindowPos(NULL, 0, 0,(int)Width,trect.bottom - trect.top ,SWP_NOMOVE);
	}
}

void CSandBoxDlg::OnSize(UINT nType, int cx, int cy) 
{
	CDialog::OnSize(nType, cx, cy);
/*
SIZE_RESTORED       0
SIZE_MINIMIZED      1
SIZE_MAXIMIZED      2
SIZE_MAXSHOW        3
SIZE_MAXHIDE        4
*/
	if (nType == SIZE_MINIMIZED) return;

	RECT trect;
	HWND thwnd = (HWND)m_SandBoxWB.GetHWNDMainWnd();
	::GetWindowRect(thwnd, &trect);
	//This will cause all contained WB's to be resized
	::SetWindowPos(thwnd, 0, 0, 0, cx , cy,SWP_NOACTIVATE | SWP_NOZORDER);
}
