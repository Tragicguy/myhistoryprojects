// MFCDemoDlg.h : header file
//
//{{AFX_INCLUDES()
#include "vbwb.h"
#include "FindDlg.h"	// Added by ClassView
#include "SandBoxDlg.h"	// Added by ClassView
//}}AFX_INCLUDES

#if !defined(AFX_MFCDEMODLG_H__FBB9C3EE_D545_45D6_B57A_8F6143B81023__INCLUDED_)
#define AFX_MFCDEMODLG_H__FBB9C3EE_D545_45D6_B57A_8F6143B81023__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CMFCDemoDlg dialog

class CMFCDemoDlg : public CDialog
{
// Construction
public:
	CMFCDemoDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CMFCDemoDlg)
	enum { IDD = IDD_MFCDEMO_DIALOG };
	CComboBox	m_Url;
	CComboBox	m_Zoom;
	CTabCtrl	m_wbtabs;
	CEdit	m_Log;
	CEdit	m_Urlgo;
	CvbWB	m_WBctl;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMFCDemoDlg)
	public:
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CMFCDemoDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnGo();
	afx_msg void OnStatusTextChangeVbwb1(short wbUID, LPCTSTR Text);
	afx_msg void OnTitleChangeVbwb1(short wbUID, LPCTSTR Text);
	afx_msg void OnBeforeNavigate2Vbwb1(short wbUID, VARIANT FAR* URL, LPDISPATCH pDisp, VARIANT FAR* Flags, VARIANT FAR* TargetFrameName, VARIANT FAR* PostData, VARIANT FAR* Headers, BOOL FAR* Cancel);
	afx_msg void OnDocumentCompleteVbwb1(short wbUID, VARIANT FAR* URL, LPDISPATCH pDisp, BOOL isTopLevel);
	afx_msg void OnFileDownloadExVbwb1(short wbUID, short FileDlUID, LPCTSTR sURL, LPCTSTR sFilename, LPCTSTR sExt, LPCTSTR sExtraHeaders, LPCTSTR sRedirURL, BOOL FAR* SendProgressEvents, BOOL FAR* bStopDownload, BSTR FAR* sPathToSave);
	afx_msg void OnOnFileDLEndDownloadVbwb1(short FileDlUID, LPCTSTR sURL);
	afx_msg void OnOnAcceletorKeysVbwb1(short wbUID, short nKeyCode, short nVirtExtKey, BOOL FAR* Cancel);
	afx_msg void OnOnContextMenuVbwb1(short wbUID, long ContextMenuType, long X, long Y, LPDISPATCH ObjElem, BOOL FAR* ctxDisplay);
	afx_msg void OnOnHTTPSecurityProblemVbwb1(short wbUID, long lProblem, BOOL FAR* Cancel);
	afx_msg void OnProtocolHandlerOnBeginTransactionVbwb1(short wbUID, LPCTSTR sURL, LPCTSTR sRequestHeaders, BSTR FAR* sAdditionalHeaders, BOOL FAR* Cancel);
	afx_msg void OnProtocolHandlerOnResponseVbwb1(short wbUID, LPCTSTR sURL, LPCTSTR sResponseHeaders, LPCTSTR sRedirectedUrl, LPCTSTR sRedirectHeaders, BOOL FAR* Cancel);
	afx_msg void OnShowMessageVbwb1(short wbUID, BSTR FAR* sMsg, BOOL FAR* ShowMsg);
	afx_msg void OnNavigateErrorVbwb1(short wbUID, LPDISPATCH pDisp, VARIANT FAR* URL, VARIANT FAR* TargetFrameName, VARIANT FAR* StatusCode, BOOL FAR* Cancel);
	afx_msg void OnOnAuthenticationVbwb1(short wbUID, BSTR FAR* sUsername, BSTR FAR* sPassword, BOOL FAR* Cancel);
	afx_msg void OnOnFileDLDownloadErrorVbwb1(short FileDlUID, LPCTSTR sURL, LPCTSTR sErrorMsg);
	afx_msg void OnChkhttpprotocols();
	afx_msg void OnClose();
	afx_msg LRESULT OnFindText(WPARAM WParam, LPARAM lParam);
	afx_msg void OnBtnsandbox();
	afx_msg void OnSelchangeWbTabs(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnBackBtn();
	afx_msg void OnStopBtn();
	afx_msg void OnForwardBtn();
	afx_msg void OnCommandStateChangeVbwb1(short wbUID, long Command, BOOL Enable);
	afx_msg void OnBtnthumbnails();
	afx_msg void OnButtonzoom();
	afx_msg void OnBtnSaveasbitmap();
	afx_msg void OnBtnPostdata();
	afx_msg void OnOnPostResponseVbwb1(short PostUID, LPCTSTR sURL, long lResponseCode, LPCTSTR sResponseHeaders);
	afx_msg void OnOnPostOnProgressVbwb1(short PostUID, LPCTSTR sURL, long lProgress, long lProgressMax, long lStatusCode, LPCTSTR sStatusText, BOOL FAR* CancelPost);
	afx_msg void OnOnPostErrorVbwb1(short PostUID, LPCTSTR sURL, LPCTSTR sErrorMsg);
	afx_msg void OnOnPostEndVbwb1(short PostUID, LPCTSTR sURL);
	afx_msg void OnOnPostDataAvailableVbwb1(short PostUID, LPCTSTR sURL, LPCTSTR pData, BOOL FAR* CancelPost);
	afx_msg void OnOnWBDragEnterVbwb1(short wbUID, short KeyState, long ptX, long ptY, long FAR* lEffect);
	afx_msg void OnOnWBDragLeaveVbwb1(short wbUID);
	afx_msg void OnOnWBDragOverVbwb1(short wbUID, short KeyState, long ptX, long ptY, long FAR* lEffect);
	afx_msg void OnOnWBDrop2Vbwb1(short wbUID, short KeyState, long ptX, long ptY, VARIANT FAR* vData, long FAR* lEffect);
	afx_msg void OnOnFileDLResponseVbwb1(short FileDlUID, LPCTSTR sURL, long lResponseCode, LPCTSTR sResponseHeaders, BOOL FAR* CancelDl);
	afx_msg void OnNewWindow3Vbwb1(short wbUID, LPDISPATCH FAR* ppDisp, BOOL FAR* Cancel, long lFlags, LPCTSTR sURLContext, LPCTSTR sURL);
	afx_msg void OnOnGetOptionKeyPathVbwb1(short wbUID, BSTR FAR* sRegistryOptionKeyPath);
	afx_msg void OnOnGetOverrideKeyPathVbwb1(short wbUID, BSTR FAR* sRegistryOverrideKeyPath);
	afx_msg void OnNewWindow2Vbwb1(short wbUID, LPDISPATCH FAR* ppDisp, BOOL FAR* Cancel);
	afx_msg void OnOnWBDropVbwb1(short wbUID, short KeyState, long ptX, long ptY, LPCTSTR lpData, long lWBDropFormat, long FAR* lEffect);
	afx_msg void OnDocumentCompleteWBExVbwb1(short wbUID, VARIANT FAR* URL, LPDISPATCH pDisp, BOOL isTopLevel, LPCTSTR sDocSource);
	afx_msg void OnChksource();
	afx_msg void OnWBProcessUrlActionVbwb1(short wbUID, LPCTSTR sURL, long lUrlAction, long PUAF_Flag, long FAR* lpUrlPolicy, BOOL FAR* bHandled);
	DECLARE_EVENTSINK_MAP()
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
private:
	short m_SandboxWB;
	void ClearBSTRPtr(BSTR& bstrText);
	void Log(LPCTSTR psz);
	short m_CurWB;
	CSandBoxDlg m_SandBoxDlg;
	CFindDlg m_FindDlg;
	BOOL IsWin2K(bool *bIsWindowsXPorLater);
	BOOL MyInitCommonControls(DWORD dwFlags);
	//Stream helpers
	HRESULT StreamResetPointer(LPSTREAM lpStream);
	//lpulSize includes terminating NULL
	HRESULT StreamStringSize(LPSTREAM lpStream, ULONG* lpulSize);
	HRESULT StreamStringCopy(LPSTREAM lpStream, LPCTSTR lpString);
	HRESULT StreamStringCat(LPSTREAM lpStream, LPCTSTR lpString);
	HRESULT StreamStringRead(LPSTREAM lpStream, LPTSTR lpszReceiver, ULONG* lpulSizeReceiver);
	CString strLog;
	CDWordArray m_BackBtns;
	CDWordArray m_ForwardBtns;
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MFCDEMODLG_H__FBB9C3EE_D545_45D6_B57A_8F6143B81023__INCLUDED_)
