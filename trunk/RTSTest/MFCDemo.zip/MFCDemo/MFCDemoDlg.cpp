// MFCDemoDlg.cpp : implementation file
//

#include "stdafx.h"
#include "MFCDemo.h"
#include "MFCDemoDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

#define DLCTL_NO_BEHAVIORS_WB                      0x00008000

#define CHECK_HR(hr,label) \
if(FAILED(hr)) \
{	goto label; \
}

#define RRELEASE(ptr) \
if(ptr) \
{	ptr->Release(); \
	ptr = NULL; \
}


/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMFCDemoDlg dialog

CMFCDemoDlg::CMFCDemoDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CMFCDemoDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CMFCDemoDlg)
	//}}AFX_DATA_INIT
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CMFCDemoDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CMFCDemoDlg)
	DDX_Control(pDX, IDC_URLCOMBO, m_Url);
	DDX_Control(pDX, IDC_COMBOZOOM, m_Zoom);
	DDX_Control(pDX, IDC_WB_TABS, m_wbtabs);
	DDX_Control(pDX, IDC_EDIT2, m_Log);
	DDX_Control(pDX, IDC_VBWB1, m_WBctl);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CMFCDemoDlg, CDialog)
	//{{AFX_MSG_MAP(CMFCDemoDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_BUTTON1, OnGo)
	ON_BN_CLICKED(IDC_CHKHTTPPROTOCOLS, OnChkhttpprotocols)
	ON_WM_CLOSE()
	ON_REGISTERED_MESSAGE(UWM_FINDTEXT, OnFindText)
	ON_BN_CLICKED(IDC_BTNSANDBOX, OnBtnsandbox)
	ON_NOTIFY(TCN_SELCHANGE, IDC_WB_TABS, OnSelchangeWbTabs)
	ON_BN_CLICKED(IDC_BACK_BTN, OnBackBtn)
	ON_BN_CLICKED(IDC_STOP_BTN, OnStopBtn)
	ON_BN_CLICKED(IDC_FORWARD_BTN, OnForwardBtn)
	ON_BN_CLICKED(IDC_BTNTHUMBNAILS, OnBtnthumbnails)
	ON_BN_CLICKED(IDC_BUTTONZOOM, OnButtonzoom)
	ON_BN_CLICKED(IDC_BTN_SAVEASBITMAP, OnBtnSaveasbitmap)
	ON_BN_CLICKED(IDC_BTN_POSTDATA, OnBtnPostdata)
	ON_BN_CLICKED(IDC_CHKSOURCE, OnChksource)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMFCDemoDlg message handlers

BOOL CMFCDemoDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon

/*
    Since each instance of WB created can have their own
    flags independent of each other, we can create a WB
    that has the strictess navigation flags set, so we
    can look at suspicious site without modifying registry
    and without effecting other instances of WB created by vbMHWB control
*/
	//Create an instance of needed dlgs and set their initial values
	DWORD flags = 0;

//SandBox
	m_SandBoxDlg.Create(IDD_SANDBOX_DLG, this); 	
	//Set some global properties by passing 0 for wbUID param
	//0 default, none. 1 Allow all, 2 raise event
	m_SandBoxDlg.m_SandBoxWB.SetContextMenuAction(0, 1);
    flags = DLCTL_NO_SCRIPTS | DLCTL_NO_JAVA;
    flags |= DLCTL_NO_RUNACTIVEXCTLS | DLCTL_NO_DLACTIVEXCTLS;
    flags |= DLCTL_NO_FRAMEDOWNLOAD | DLCTL_NO_BEHAVIORS_WB | DLCTL_SILENT;
	m_SandBoxDlg.m_SandBoxWB.SetDocumentDownloadControlFlags(0,(long)flags);
	//Create SandBoxDlg WB
	m_SandBoxDlg.m_SandBoxWB.AddBrowser(&m_SandBoxDlg.m_CurSandBox);
	m_SandBoxDlg.m_SandBoxWB.SetRegisterAsBrowser(m_SandBoxDlg.m_CurSandBox,VARIANT_TRUE);

	m_SandBoxDlg.SetWindowPos(NULL, 10, 10,400,300 ,SWP_NOZORDER | SWP_NOACTIVATE);

//Find
	m_FindDlg.Create(IDD_FIND_DLG, this); 
	m_FindDlg.CheckRadioButton(IDC_RDFIND_DOWNWARD,
								IDC_RDFIND_UPWARD,
								IDC_RDFIND_DOWNWARD);
	//Select the first item in the list
	::SendMessage(m_FindDlg.GetDlgItem(IDC_COMBFIND_COLORS)->GetSafeHwnd(), 
				CB_SETCURSEL, (WPARAM)0, 0);
	
	//Set zoom level to medium, most common
	m_Zoom.SetCurSel(2);

	//Set text to any URL
	m_Url.SetWindowText(_T("http://www.google.com"));

	//Uncomment to enable shell autocomplete
//	m_WBctl.SetupShellAutoComplete((long)GetDlgItem(IDC_URLCOMBO)->GetSafeHwnd(), 
//				VARIANT_TRUE, (long)(0x00000000) //Default MRU + URL );

//Set some WB Global flags	
	//Default start up URL is _T("")
	//Upon creating an instance of WB, no initial navigation takes place
	m_WBctl.SetStartupURL(_T("about:blank"));
	//Drag drop
	//Apply action to all WB's, We handle dragdrops, Allow drag drop
	m_WBctl.SetRegisterAsDropTarget(0 ,VARIANT_FALSE, VARIANT_TRUE);

	//fire events for accel
	m_WBctl.SetAcceletorKeysAction(0, 2);
	//fire events for context menus
	m_WBctl.SetContextMenuAction(0, 2);
	
	//Is themes available
	bool xpplus = false;
	if(IsWin2K(&xpplus))
	{
		//Activate themes in WB
		flags = DOCHOSTUIFLAG_NO3DBORDER | 
						DOCHOSTUIFLAG_FLAT_SCROLLBAR | 
						DOCHOSTUIFLAG_THEME;
		m_WBctl.SetDocumentHostUiFlags(0, (long)flags);
		//Setting may cause the WB to activate some of the options
		//that we have suppresed via DocumentDownloadControlFlags???
		//m_SandBoxDlg.m_SandBoxWB.SetDocumentHostUiFlags(0, (long)flags);
	}
	
	//Set up Back and Forward buttons
	m_BackBtns.Add(0);
	m_ForwardBtns.Add(0);

	//Create DemoDlg WB
	m_WBctl.AddBrowser(&m_CurWB);

	//To intercept the source of the document using DocumentCompleteWBEx event
	//before any scripts are executed, set SourceOnDocComplete property to true
	//m_WBctl.SetSourceOnDocComplete(m_CurWB, VARIANT_TRUE);

	//Insert tab and store current WB UID value in the tabs lParam
	//So we can respond to selection change event of tab ctl by bringing
	//the specific WB to the top of the stack
	m_wbtabs.InsertItem(TCIF_PARAM | TCIF_TEXT,0 , _T("about:blank"),0,(LPARAM)m_CurWB);

	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CMFCDemoDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CMFCDemoDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

HCURSOR CMFCDemoDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CMFCDemoDlg::OnClose() 
{
	CDialog::OnClose();
	//Destroy dlgs
	m_SandBoxDlg.DestroyWindow();
	m_FindDlg.DestroyWindow();
}

//Called from FindDlg via PostMessage
//WParam: 0
//LParam: 0
//Return: 0
LRESULT CMFCDemoDlg::OnFindText(WPARAM WParam, LPARAM lParam)
{
	//To modify
	//CString * s = (CString *)lParam;
	//Send it as (LPARAM)&str
	if( m_FindDlg.m_strFind.GetLength() > 0 )
	{
		//In param declared as BOOL, must be declared as VARIANT_BOOL
		//IN/OUT params declared as BOOL, are declared as BOOL
		BOOL bResult = VARIANT_TRUE;
		if(m_FindDlg.m_bHighLight == TRUE) //highlight
		{
//			try
//			{
				m_WBctl.FindAndHighlightAllText(m_CurWB, m_FindDlg.m_strFind,
								m_FindDlg.m_bMatchWholeWord ,
								m_FindDlg.m_bMatchCase,
								m_FindDlg.m_strColor , &bResult);
				if(bResult == VARIANT_FALSE)
				{
					MessageBox(_T("No matches found."));
				}
//			}
//			catch(...)
//			{				
//			}

		}
		else //Simple search
		{
			m_WBctl.FindTextSimple(m_CurWB, m_FindDlg.m_strFind, 
							m_FindDlg.m_bDownWard , m_FindDlg.m_bMatchWholeWord , 
							m_FindDlg.m_bMatchCase , VARIANT_TRUE, &bResult);
			if(bResult == VARIANT_FALSE)
			{
				MessageBox(_T("No more matches found."));
			}
		}
	}
	return 0;
}

/*
		IErrorInfo *pError = NULL;
		HRESULT hr = GetErrorInfo(0, &pError);
		if( (SUCCEEDED(hr)) && (pError) )
		{
			BSTR strErr = NULL;
			hr = pError->GetDescription(&strErr);
			if( (SUCCEEDED(hr)) && (strErr) )
			{
				CString sErr(_T("Errors->"));
				sErr += strErr;
				::SysFreeString(strErr);
				MessageBox(sErr);
			}
			else
				MessageBox(_T("Errors -> GetErrorInfo -> GetDescription -> FAILED"));
		}
		else
			MessageBox(_T("Errors -> GetErrorInfo -> FAILED")); //No errorInfo received either
*/

BOOL CMFCDemoDlg::PreTranslateMessage(MSG* pMsg) 
{
	//Allow control to process messages (Accelerator keys, ...)
	if(!m_WBctl.PreTranslateMessage(pMsg))
		return CDialog::PreTranslateMessage(pMsg);
	return TRUE;	
	//return CDialog::PreTranslateMessage(pMsg);
}

void CMFCDemoDlg::OnGo() 
{
	LPTSTR surl = new char[255];
	surl[254] = '\0';
	if(surl)
	{
		m_Url.GetWindowText(surl,254);
		//Add a new WB
		if(IsDlgButtonChecked(IDC_CHKNEWWB) == BST_CHECKED)
		{
			//Set up Back and Forward buttons
			m_BackBtns.Add(0);
			m_ForwardBtns.Add(0);
			GetDlgItem(IDC_BACK_BTN)->EnableWindow(FALSE);
			GetDlgItem(IDC_FORWARD_BTN)->EnableWindow(FALSE);

			//Add new Webbrowser
			m_WBctl.AddBrowser(&m_CurWB);

			//Add new tab
			int icount = m_wbtabs.GetItemCount();
			m_wbtabs.InsertItem(TCIF_PARAM | TCIF_TEXT, icount , 
				_T("New"), 0, (LPARAM)m_CurWB);

			//Update count
			TCHAR buff[10];
			#ifdef UNICODE
				_itow(icount+1, buff, 10);
			#else
				_itoa(icount+1, buff, 10);
			#endif
			SetDlgItemText(IDC_WBCOUNT_STATIC, buff);

			m_wbtabs.SetCurSel(icount);
		}
		//Navigate
		m_WBctl.NavigateSimple(m_CurWB, surl);
		delete[] surl;
		m_WBctl.PlaceWBOnTop(m_CurWB);
		m_WBctl.SetFocusW(m_CurWB);
	}
}

void CMFCDemoDlg::Log(LPCTSTR psz)
{
	strLog.Empty();
	strLog = psz;
	strLog += _T("\r\n");
	strLog.ReleaseBuffer();
	int len = m_Log.GetWindowTextLength();
	m_Log.SendMessage(EM_SETSEL, len, len);
	m_Log.SendMessage(EM_REPLACESEL, FALSE, reinterpret_cast<LPARAM>((LPCTSTR)strLog));
}

/////////////////////////////////
//Common Controls initialization helper, taken from WTL
//ICC_ANIMATE_CLASS  Load animate control class.  
//ICC_BAR_CLASSES  Load toolbar, status bar, trackbar, and tooltip control classes.  
//ICC_COOL_CLASSES  Load rebar control class.  
//ICC_DATE_CLASSES  Load date and time picker control class.  
//ICC_HOTKEY_CLASS  Load hot key control class.  
//ICC_INTERNET_CLASSES  Load IP address class.  
//ICC_LISTVIEW_CLASSES  Load list view and header control classes.  
//ICC_PAGESCROLLER_CLASS  Load pager control class.  
//ICC_PROGRESS_CLASS  Load progress bar control class.  
//ICC_TAB_CLASSES  Load tab and tooltip control classes.  
//ICC_TREEVIEW_CLASSES  Load tree view and tooltip control classes.  
//ICC_UPDOWN_CLASS  Load up-down control class.  
//ICC_USEREX_CLASSES  Load ComboBoxEx class.  
//ICC_WIN95_CLASSES  Load animate control, header, hot key, list view, progress bar, status bar, tab, tooltip, toolbar, trackbar, tree view, and up-down control classes. 
BOOL CMFCDemoDlg::MyInitCommonControls(DWORD dwFlags)
{
	INITCOMMONCONTROLSEX iccx = { sizeof(INITCOMMONCONTROLSEX), dwFlags };
	BOOL bRet = ::InitCommonControlsEx(&iccx);
	return bRet;
}

//To find Win version
BOOL CMFCDemoDlg::IsWin2K(bool *bIsWindowsXPorLater)
{
	//From MSDN
	//http://msdn.microsoft.com/library/default.asp?url=/library/en-us/sysinfo/base/operating_system_version.asp
	
	//Assume not in 95/98/ME win family
	BOOL bRet = TRUE;

	OSVERSIONINFOEX osvi;
	BOOL bOsVersionInfoEx;

	// Try calling GetVersionEx using the OSVERSIONINFOEX structure.
	// If that fails, try using the OSVERSIONINFO structure.

	ZeroMemory(&osvi, sizeof(OSVERSIONINFOEX));
	osvi.dwOSVersionInfoSize = sizeof(OSVERSIONINFOEX);

	if( !(bOsVersionInfoEx = GetVersionEx ((OSVERSIONINFO *) &osvi)) )
	{
	  osvi.dwOSVersionInfoSize = sizeof (OSVERSIONINFO);
	  if (! GetVersionEx ( (OSVERSIONINFO *) &osvi) ) 
		 return FALSE;
	}
	//Windows NT product family
	//if( osvi.dwPlatformId == VER_PLATFORM_WIN32_NT )
	if( osvi.dwPlatformId == VER_PLATFORM_WIN32_WINDOWS)
		bRet = FALSE;
	*bIsWindowsXPorLater =  ( (osvi.dwMajorVersion > 5) || 
							( (osvi.dwMajorVersion == 5) && (osvi.dwMinorVersion >= 1) ) );
	return bRet;
}

//To clear BSTR before setting it's value
//Needed to clear BSTR param passed byRef
//ClearBSTRPtr(*bstr);
void CMFCDemoDlg::ClearBSTRPtr(BSTR &bstrText)
{
	if (bstrText != NULL)
	{
		::SysFreeString(bstrText);
		bstrText = NULL;
	}
}

/*Sample usage

TCHAR *ppString[3] = 
{
  "Hey diddle diddle...",
  "The cat and the fiddle...",
  "The cow jumps over the moon..."
};


long MemoryStringTest_Function()
{
  LPTSTR pszString = NULL;
  ULONG ulSizeRequired = 0;
  ULONG ulCount = 0;
  int i = 0;
  LPSTREAM lpStream = NULL;

  CreateStreamOnHGlobal(NULL, TRUE, &lpStream);

  StreamStringCopy ((LPSTREAM)lpStream, (LPCTSTR)"");

  for (i = 0; i < 3; i++)
  {
	StreamStringCat ((LPSTREAM)lpStream, ppString[i]);
  }

  StreamStringRead ((LPSTREAM)lpStream, (LPTSTR)NULL, (ULONG*)&ulSizeRequired);

  pszString = (LPTSTR)malloc(ulSizeRequired + sizeof(char));

  if (pszString)
  {
	StreamStringRead ((LPSTREAM)lpStream, (LPTSTR)pszString, (ULONG*)NULL);
	free (pszString);
	pszString = NULL;
  }

  StreamStringCopy ((LPSTREAM)lpStream, (LPCTSTR)"The dish ran away with the spoon.");

  StreamStringRead ((LPSTREAM)lpStream, (LPTSTR)NULL, (ULONG*)&ulSizeRequired);

  pszString = (LPTSTR)malloc(ulSizeRequired + sizeof(char));
  if (pszString)
  {
	StreamStringRead ((LPSTREAM)lpStream, (LPTSTR)pszString, (ULONG*)NULL);
	free (pszString);
	pszString = NULL;
  }

  if (lpStream)
  {
    lpStream -> Release();
	lpStream = NULL;
  }

  return 0;
}
*/

HRESULT CMFCDemoDlg::StreamResetPointer (LPSTREAM lpStream)
{
  LARGE_INTEGER liBeggining = { 0 };
  HRESULT hrRet = S_OK;

  hrRet = lpStream -> Seek(liBeggining, STREAM_SEEK_SET, NULL);

  return hrRet;
}

HRESULT CMFCDemoDlg::StreamStringCopy (LPSTREAM lpStream, LPCTSTR lpString)
{
  ULONG ulBytesWritten = 0;
  ULONG ulSize = 0;
  ULARGE_INTEGER uliSize = { 0 };
  HRESULT hrRetTemp = S_OK;
  HRESULT hrRet = S_OK;

  hrRetTemp = StreamResetPointer ((LPSTREAM)lpStream);
  if (hrRetTemp != S_OK)
  {
    hrRet = hrRetTemp;
	goto StreamStringCopy_0;
  }

  hrRetTemp = lpStream -> SetSize (uliSize);
  if (hrRetTemp != S_OK)
  {
    hrRetTemp = hrRet;
	goto StreamStringCopy_0;
  }

  ulSize = (ULONG)_tcslen(lpString);
  
  hrRetTemp = lpStream -> Write((void const*)lpString, (ULONG)ulSize, (ULONG*)&ulBytesWritten);
  if (hrRetTemp != S_OK)
  {
    hrRet = hrRetTemp;
	goto StreamStringCopy_0;
  }

  if (ulSize == ulBytesWritten)
  {
    hrRet = S_OK;
  }
  else
  {
    hrRet = S_FALSE;
  }

StreamStringCopy_0:

  return hrRet;
}

HRESULT CMFCDemoDlg::StreamStringCat (LPSTREAM lpStream, LPCTSTR lpString)
{
  ULONG ulBytesWritten = 0;
  ULONG ulSize = 0;
  HRESULT hrRetTemp = S_OK;
  HRESULT hrRet = S_OK;

  ulSize = (ULONG)_tcslen(lpString);
  
  hrRetTemp = lpStream -> Write((void const*)lpString, (ULONG)ulSize, (ULONG*)&ulBytesWritten);
  if (hrRetTemp != S_OK)
  {
    hrRet = hrRetTemp;
	goto StreamStringCat_0;
  }

  if (ulSize == ulBytesWritten)
  {
    hrRet = S_OK;
  }
  else
  {
    hrRet = S_FALSE;
  }

StreamStringCat_0:

  return hrRet;
}

HRESULT CMFCDemoDlg::StreamStringSize(LPSTREAM lpStream, ULONG* lpulSize)
{
  STATSTG statstg;
  HRESULT hrRetTemp = S_OK;
  HRESULT hrRet = S_OK;

  hrRetTemp = StreamResetPointer ((LPSTREAM)lpStream);
  if (hrRetTemp != S_OK)
  {
    hrRet = hrRetTemp;
    goto StreamStringSize_0;
  }

  memset (&statstg, 0, sizeof(statstg));
  hrRetTemp = lpStream -> Stat(&statstg, STATFLAG_NONAME);
  if (hrRetTemp != S_OK)
  {
    hrRet = hrRetTemp;
	goto StreamStringSize_0;
  }

  if ((ULONG*)lpulSize)
  {
    *((ULONG*)lpulSize) = statstg.cbSize.LowPart;
  }

StreamStringSize_0:

  return hrRet;
}

HRESULT CMFCDemoDlg::StreamStringRead (LPSTREAM lpStream, LPTSTR lpszReceiver, ULONG* lpulSizeReceiver)
{
  STATSTG statstg;
  HRESULT hrRetTemp = S_OK;
  HRESULT hrRet = S_OK;

  hrRetTemp = StreamResetPointer ((LPSTREAM)lpStream);
  if (hrRetTemp != S_OK)
  {
    hrRet = hrRetTemp;
    goto StreamStringRead_0;
  }

  memset (&statstg, 0, sizeof(statstg));
  hrRetTemp = lpStream -> Stat(&statstg, STATFLAG_NONAME);
  if (hrRetTemp != S_OK)
  {
    hrRet = hrRetTemp;
	goto StreamStringRead_0;
  }

  if ((ULONG*)lpulSizeReceiver)
  {
    *((ULONG*)lpulSizeReceiver) = statstg.cbSize.LowPart;
  }

  if ((void*)lpszReceiver)
  {
    memset ((void*)lpszReceiver, 0, statstg.cbSize.LowPart + sizeof(char));
    lpStream -> Read((void*)lpszReceiver, statstg.cbSize.LowPart, NULL);
  }

StreamStringRead_0:

  return hrRet;
}

/////////////////////////////////////////
//EVENTS
/////////////////////////////////////////

BEGIN_EVENTSINK_MAP(CMFCDemoDlg, CDialog)
    //{{AFX_EVENTSINK_MAP(CMFCDemoDlg)
	ON_EVENT(CMFCDemoDlg, IDC_VBWB1, 1 /* StatusTextChange */, OnStatusTextChangeVbwb1, VTS_I2 VTS_BSTR)
	ON_EVENT(CMFCDemoDlg, IDC_VBWB1, 6 /* TitleChange */, OnTitleChangeVbwb1, VTS_I2 VTS_BSTR)
	ON_EVENT(CMFCDemoDlg, IDC_VBWB1, 8 /* BeforeNavigate2 */, OnBeforeNavigate2Vbwb1, VTS_I2 VTS_PVARIANT VTS_DISPATCH VTS_PVARIANT VTS_PVARIANT VTS_PVARIANT VTS_PVARIANT VTS_PBOOL)
	ON_EVENT(CMFCDemoDlg, IDC_VBWB1, 11 /* DocumentComplete */, OnDocumentCompleteVbwb1, VTS_I2 VTS_PVARIANT VTS_DISPATCH VTS_BOOL)
	ON_EVENT(CMFCDemoDlg, IDC_VBWB1, 30 /* FileDownloadEx */, OnFileDownloadExVbwb1, VTS_I2 VTS_I2 VTS_BSTR VTS_BSTR VTS_BSTR VTS_BSTR VTS_BSTR VTS_PBOOL VTS_PBOOL VTS_PBSTR)
	ON_EVENT(CMFCDemoDlg, IDC_VBWB1, 34 /* OnFileDLEndDownload */, OnOnFileDLEndDownloadVbwb1, VTS_I2 VTS_BSTR)
	ON_EVENT(CMFCDemoDlg, IDC_VBWB1, 27 /* OnAcceletorKeys */, OnOnAcceletorKeysVbwb1, VTS_I2 VTS_I2 VTS_I2 VTS_PBOOL)
	ON_EVENT(CMFCDemoDlg, IDC_VBWB1, 26 /* OnContextMenu */, OnOnContextMenuVbwb1, VTS_I2 VTS_I4 VTS_I4 VTS_I4 VTS_DISPATCH VTS_PBOOL)
	ON_EVENT(CMFCDemoDlg, IDC_VBWB1, 42 /* OnHTTPSecurityProblem */, OnOnHTTPSecurityProblemVbwb1, VTS_I2 VTS_I4 VTS_PBOOL)
	ON_EVENT(CMFCDemoDlg, IDC_VBWB1, 43 /* ProtocolHandlerOnBeginTransaction */, OnProtocolHandlerOnBeginTransactionVbwb1, VTS_I2 VTS_BSTR VTS_BSTR VTS_PBSTR VTS_PBOOL)
	ON_EVENT(CMFCDemoDlg, IDC_VBWB1, 44 /* ProtocolHandlerOnResponse */, OnProtocolHandlerOnResponseVbwb1, VTS_I2 VTS_BSTR VTS_BSTR VTS_BSTR VTS_BSTR VTS_PBOOL)
	ON_EVENT(CMFCDemoDlg, IDC_VBWB1, 22 /* ShowMessage */, OnShowMessageVbwb1, VTS_I2 VTS_PBSTR VTS_PBOOL)
	ON_EVENT(CMFCDemoDlg, IDC_VBWB1, 12 /* NavigateError */, OnNavigateErrorVbwb1, VTS_I2 VTS_DISPATCH VTS_PVARIANT VTS_PVARIANT VTS_PVARIANT VTS_PBOOL)
	ON_EVENT(CMFCDemoDlg, IDC_VBWB1, 41 /* OnAuthentication */, OnOnAuthenticationVbwb1, VTS_I2 VTS_PBSTR VTS_PBSTR VTS_PBOOL)
	ON_EVENT(CMFCDemoDlg, IDC_VBWB1, 35 /* OnFileDLDownloadError */, OnOnFileDLDownloadErrorVbwb1, VTS_I2 VTS_BSTR VTS_BSTR)
	ON_EVENT(CMFCDemoDlg, IDC_VBWB1, 3 /* CommandStateChange */, OnCommandStateChangeVbwb1, VTS_I2 VTS_I4 VTS_BOOL)
	ON_EVENT(CMFCDemoDlg, IDC_VBWB1, 58 /* OnPostResponse */, OnOnPostResponseVbwb1, VTS_I2 VTS_BSTR VTS_I4 VTS_BSTR)
	ON_EVENT(CMFCDemoDlg, IDC_VBWB1, 55 /* OnPostOnProgress */, OnOnPostOnProgressVbwb1, VTS_I2 VTS_BSTR VTS_I4 VTS_I4 VTS_I4 VTS_BSTR VTS_PBOOL)
	ON_EVENT(CMFCDemoDlg, IDC_VBWB1, 56 /* OnPostError */, OnOnPostErrorVbwb1, VTS_I2 VTS_BSTR VTS_BSTR)
	ON_EVENT(CMFCDemoDlg, IDC_VBWB1, 57 /* OnPostEnd */, OnOnPostEndVbwb1, VTS_I2 VTS_BSTR)
	ON_EVENT(CMFCDemoDlg, IDC_VBWB1, 53 /* OnPostDataAvailable */, OnOnPostDataAvailableVbwb1, VTS_I2 VTS_BSTR VTS_BSTR VTS_PBOOL)
	ON_EVENT(CMFCDemoDlg, IDC_VBWB1, 48 /* OnWBDragEnter */, OnOnWBDragEnterVbwb1, VTS_I2 VTS_I2 VTS_I4 VTS_I4 VTS_PI4)
	ON_EVENT(CMFCDemoDlg, IDC_VBWB1, 51 /* OnWBDragLeave */, OnOnWBDragLeaveVbwb1, VTS_I2)
	ON_EVENT(CMFCDemoDlg, IDC_VBWB1, 49 /* OnWBDragOver */, OnOnWBDragOverVbwb1, VTS_I2 VTS_I2 VTS_I4 VTS_I4 VTS_PI4)
	ON_EVENT(CMFCDemoDlg, IDC_VBWB1, 54 /* OnWBDrop2 */, OnOnWBDrop2Vbwb1, VTS_I2 VTS_I2 VTS_I4 VTS_I4 VTS_PVARIANT VTS_PI4)
	ON_EVENT(CMFCDemoDlg, IDC_VBWB1, 37 /* OnFileDLResponse */, OnOnFileDLResponseVbwb1, VTS_I2 VTS_BSTR VTS_I4 VTS_BSTR VTS_PBOOL)
	ON_EVENT(CMFCDemoDlg, IDC_VBWB1, 45 /* NewWindow3 */, OnNewWindow3Vbwb1, VTS_I2 VTS_PDISPATCH VTS_PBOOL VTS_I4 VTS_BSTR VTS_BSTR)
	ON_EVENT(CMFCDemoDlg, IDC_VBWB1, 46 /* OnGetOptionKeyPath */, OnOnGetOptionKeyPathVbwb1, VTS_I2 VTS_PBSTR)
	ON_EVENT(CMFCDemoDlg, IDC_VBWB1, 47 /* OnGetOverrideKeyPath */, OnOnGetOverrideKeyPathVbwb1, VTS_I2 VTS_PBSTR)
	ON_EVENT(CMFCDemoDlg, IDC_VBWB1, 9 /* NewWindow2 */, OnNewWindow2Vbwb1, VTS_I2 VTS_PDISPATCH VTS_PBOOL)
	ON_EVENT(CMFCDemoDlg, IDC_VBWB1, 50 /* OnWBDrop */, OnOnWBDropVbwb1, VTS_I2 VTS_I2 VTS_I4 VTS_I4 VTS_BSTR VTS_I4 VTS_PI4)
	ON_EVENT(CMFCDemoDlg, IDC_VBWB1, 59 /* DocumentCompleteWBEx */, OnDocumentCompleteWBExVbwb1, VTS_I2 VTS_PVARIANT VTS_DISPATCH VTS_BOOL VTS_BSTR)
	ON_EVENT(CMFCDemoDlg, IDC_VBWB1, 60 /* WBProcessUrlAction */, OnWBProcessUrlActionVbwb1, VTS_I2 VTS_BSTR VTS_I4 VTS_I4 VTS_PI4 VTS_PBOOL)
	//}}AFX_EVENTSINK_MAP
END_EVENTSINK_MAP()

void CMFCDemoDlg::OnStatusTextChangeVbwb1(short wbUID, LPCTSTR Text) 
{
	SetDlgItemText(IDC_STATIC_STATUS, Text);
}

void CMFCDemoDlg::OnTitleChangeVbwb1(short wbUID, LPCTSTR Text) 
{
	SetWindowText(Text);
	int isel = m_wbtabs.GetCurSel();
	if(isel > -1)
	{
		TCITEM pitem;
		pitem.mask = TCIF_TEXT;
		CString str(Text);
		//No more than 25 characters
		pitem.pszText = str.GetBufferSetLength(25); //(LPTSTR)Text;
		m_wbtabs.SetItem(isel, &pitem);
	}
}

void CMFCDemoDlg::OnBeforeNavigate2Vbwb1(short wbUID, VARIANT FAR* URL, LPDISPATCH pDisp, VARIANT FAR* Flags, VARIANT FAR* TargetFrameName, VARIANT FAR* PostData, VARIANT FAR* Headers, BOOL FAR* Cancel) 
{
	if(URL->vt == VT_BSTR)
	{
		CString str(URL->bstrVal); //(_T("OnBeforeNavigate2>>> "));
		//str += URL->bstrVal;
		//Do not bother with about:blank
		if(str == _T("about:blank") )
			return;

		BOOL bOk = VARIANT_FALSE;
		m_WBctl.ucInternetCrackUrl(str, &bOk);
		if (bOk == VARIANT_FALSE)
		{
			str += _T("\r\nUnable to process this URL!");
			m_WBctl.Stop(wbUID);
			m_WBctl.NavigateSimple(wbUID, _T("about:blank"));
		}
		Log(str);
	}
}

// Get the DOM associated with the WebBrowser that threw this event, and
// inject an onerror tag into the page in hopes of receiving an
// OLECMDID_SHOWSCRIPTERROR message. (This is a bug in Internet Explorer 6.)
// NOTE: pBrowser is the IWebBrowser2 for the FRAME, IFRAME, or primary
// that just finished loading our document. If you have a FRAMESET with
// three FRAMEs, you will see this handler called four times: once for
// each FRAME and once for the FRAMESET after all FRAMEs have loaded.
// We're sinking each individual FRAME in this sample; to sink only the
// topmost FRAME, test the IUnknown of our m_pBrowser against the IUnknown
// of this method's pBrowser, and sink only when these two are equal.
void CMFCDemoDlg::OnDocumentCompleteVbwb1(short wbUID, VARIANT FAR* URL, LPDISPATCH pDisp, BOOL isTopLevel) 
{

	//isTopLevel indicates that the main document has fully loaded
	if( (isTopLevel) && (URL->vt == VT_BSTR))
	{
		CString strt1(URL->bstrVal); //(_T("OnDocumentCompleteVbwb1>>> "));
		//strt1 += URL->bstrVal;
		if(strt1 == _T("about:blank") )
			return;
		Log(strt1);
		m_WBctl.SetFocusW(wbUID);
	}

}

/*
'This event is called in place of FileDownload event if UseIEDefaultFileDownload = False
'
'FileDlUID, UID for this file download, can be used to stop a DL using CancelFileDl method
'Default, SendProgressEvents = True (sends OnFileDLProgress)
'sFilename= xxx.zip
'sExt= .zip
'sURL= http://www.site.com/folder/xxxxx/xxx.zip
'sRedirURL= Url of the site we have been redirected to
'sExtraHeaders= Response headers received from server in response to our request
'Default, bStopDownload = False
'sPathToSave= Must be in form of Fullpath/Filename.ext. if no value is passed
'then the file will be saved in the same directory as the exe with the format sFilename/sExt
*/
void CMFCDemoDlg::OnFileDownloadExVbwb1(short wbUID, short FileDlUID, LPCTSTR sURL, LPCTSTR sFilename, LPCTSTR sExt, LPCTSTR sExtraHeaders, LPCTSTR sRedirURL, BOOL FAR* SendProgressEvents, BOOL FAR* bStopDownload, BSTR FAR* sPathToSave) 
{
/*
//Uncomment this part to download to a given directory
//Replace "C:\\SomeFolderMustExists\\" with your path
	CString strPath(_T("C:\\SomeFolderMustExists\\"));
	strPath += sFilename;
	//This will be freed by the control
	BSTR bstrPath = strPath.AllocSysString();
	if( (bstrPath) && (sPathToSave != NULL) )
	{
		//Clear the ptr before setting value else mem leak!
		ClearBSTRPtr(*sPathToSave);
		//Copy what we have to the out parameter
		*sPathToSave = ::SysAllocStringLen(bstrPath, ::SysStringLen(bstrPath));
		//Free string
		::SysFreeString(bstrPath);
	}
*/
	*SendProgressEvents = VARIANT_FALSE;
	CString str(_T("OnFileDownloadEx>>> "));
	str += sURL;
	str += _T("\r\nFileName>>> ");
	str += sFilename;
	str += _T("\r\nResponse Headers>>>\r\n");
	str += sExtraHeaders;
	Log(str);
}

void CMFCDemoDlg::OnOnFileDLEndDownloadVbwb1(short FileDlUID, LPCTSTR sURL) 
{
	CString str(_T("OnOnFileDLEndDownload>>> "));
	str += sURL;
	Log(str);
}

//Default value of Cancel = VARIANT_FALSE
/* VK_A thru VK_Z are the same as ASCII 'A' thru 'Z' (0x41 - 0x5A) */
void CMFCDemoDlg::OnOnAcceletorKeysVbwb1(short wbUID, short nKeyCode, short nVirtExtKey, BOOL FAR* Cancel) 
{
	CString str;
	if(nVirtExtKey == VK_CONTROL)
	{
		switch (nKeyCode)
		{
		case 0x41: //A
			{
				str = _T("OnOnAcceletorKeysVbwb1_VK_CONTROL_VK_A");
			}
			break;
		case 0x43: //C
			{
				str = _T("OnOnAcceletorKeysVbwb1_VK_CONTROL_VK_C");
			}
			break;
		case 0x45: //E
			{
				str = _T("OnOnAcceletorKeysVbwb1_VK_CONTROL_VK_E");
			}
			break;
		case 0x46: //F
			{
				*Cancel = VARIANT_TRUE;
				//Dispaly our own find dlg
				if(!m_FindDlg.IsWindowVisible())
					m_FindDlg.ShowWindow(TRUE);
				else
					m_FindDlg.SetActiveWindow();
				return;
				//str = _T("OnOnAcceletorKeysVbwb1_VK_CONTROL_VK_F");
			}
			break;
		case 0x48: //H
			{
				str = _T("OnOnAcceletorKeysVbwb1_VK_CONTROL_VK_H");
			}
			break;
		case 0x49: //I
			{
				str = _T("OnOnAcceletorKeysVbwb1_VK_CONTROL_VK_I");
			}
			break;
		case 0x4E: //N
			{
				*Cancel =  VARIANT_TRUE;
				str = _T("OnOnAcceletorKeysVbwb1_VK_CONTROL_VK_N");
			}
			break;
		case 0x4F: //O
			{
				*Cancel =  VARIANT_TRUE;
				str = _T("OnOnAcceletorKeysVbwb1_VK_CONTROL_VK_O");
			}
			break;
		case 0x50: //P
			{
				*Cancel =  VARIANT_TRUE;
				str = _T("OnOnAcceletorKeysVbwb1_VK_CONTROL_VK_P");
			}
			break;
		case 0x56: //V
			{
				str = _T("OnOnAcceletorKeysVbwb1_VK_CONTROL_VK_V");
			}
			break;
		case 0x58: //X
			{
				str = _T("OnOnAcceletorKeysVbwb1_VK_CONTROL_VK_X");
			}
			break;
		default:
			{
				str = _T("OnOnAcceletorKeysVbwb1_VK_CONTROL_VK_UNKNOWN");
			}
		}
	}
	else if(nVirtExtKey == VK_MENU)
	{
		switch (nKeyCode)
		{
		case VK_HOME:
			{
				str = _T("OnOnAcceletorKeysVbwb1_VK_MENU_VK_HOME");
			}
			break;
		case VK_LEFT:
			{
				str = _T("OnOnAcceletorKeysVbwb1_VK_MENU_VK_LEFT");
			}
			break;
		case VK_RIGHT:
			{
				str = _T("OnOnAcceletorKeysVbwb1_VK_MENU_VK_RIGHT");
			}
			break;
		default:
			{
				str = _T("OnOnAcceletorKeysVbwb1_VK_MENU_VK_UNKNOWN");
			}
		}
	}
	else
	{
		str = _T("OnOnAcceletorKeysVbwb1_VK_UNKNOWN");
	}
	Log(str);
}


//ContextMenuType, one of CONTEXT_MENU_xxx enum
//default value of ctxDisplay = VARIANT_FALSE
//X and Y are based on screen coordinates
//ObjElem is the dispatch of HTMLElement that generated this event
void CMFCDemoDlg::OnOnContextMenuVbwb1(short wbUID, long ContextMenuType, long X, long Y, LPDISPATCH ObjElem, BOOL FAR* ctxDisplay) 
{
	CString str;
	IDispatch *pDisp = NULL;
	IHTMLElement *pElem = NULL;
	IHTMLAnchorElement *pAElem = NULL;
	HRESULT hr = S_FALSE;

	switch (ContextMenuType)
	{
	case CONTEXT_MENU_DEFAULT:
		{
			*ctxDisplay = VARIANT_TRUE;
			str = _T("OnOnContextMenuVbwb1_CONTEXT_MENU_DEFAULT");
		}
		break;
	case CONTEXT_MENU_CONTROL:
		{
			str = _T("OnOnContextMenuVbwb1_CONTEXT_MENU_CONTROL");
		}
		break;
	case CONTEXT_MENU_IMAGE:
		{
			//Get image src and either Alt or Parent.Href tag values

			str = _T("OnOnContextMenuVbwb1_CONTEXT_MENU_IMAGE\r\n(src value) ");
			IHTMLImgElement *pImg = NULL;
			if(ObjElem)
			{
				//QI dispatch for HTMLImgElement
				hr = ObjElem->QueryInterface(IID_IHTMLImgElement, 
							reinterpret_cast<void**>(&pImg));
				if( (SUCCEEDED(hr)) && (pImg) )
				{
					BSTR strSrc = NULL;
					//Get the src tag
					hr = pImg->get_src(&strSrc);
					if( (SUCCEEDED(hr)) && (strSrc) )
					{
						str += strSrc;
						//Free string
						::SysFreeString(strSrc);
					}
					
					//See if this is an image within a A tag
					//OI for HTMLElement
					hr = ObjElem->QueryInterface(IID_IHTMLElement, 
							reinterpret_cast<void**>(&pElem));
					if( (SUCCEEDED(hr)) && (pElem) )
					{
						IHTMLElement *pParent = NULL;
						//Get parent HTMLElement
						hr = pElem->get_parentElement(&pParent);
						if( (SUCCEEDED(hr)) && (pParent) )
						{
							BSTR strTag = NULL;
							hr = pParent->get_tagName(&strTag);
							if( (SUCCEEDED(hr)) && (strTag) )
							{
								if( (strTag[0] == 'a') || (strTag[0] == 'A') )
								{
									//Get the HREF
									//QI for dispatch
									hr = pParent->QueryInterface(IID_IDispatch, 
										reinterpret_cast<void**>(&pDisp));
									if( (SUCCEEDED(hr)) && (pDisp) )
									{
										//QI dispatch for HTMLAnchorElemnt
										hr = pDisp->QueryInterface(IID_IHTMLAnchorElement, 
												reinterpret_cast<void**>(&pAElem));
										if( (SUCCEEDED(hr)) && (pAElem) )
										{
											BSTR strHref = NULL;
											hr = pAElem->get_href(&strHref);
											if( (SUCCEEDED(hr)) && (strHref) )
											{
												str += _T("\r\n(HREF tag value) ");
												str += strHref;
												::SysFreeString(strHref);
											}
											pAElem->Release();
										}
										else
										{
											str += _T("\r\n(Element not available)");
										}
										pDisp->Release();
									}
									else
									{
										str += _T("\r\n(Href pDisp not available)");
									}
								}
								else //just use alt tag value
								{
									BSTR strAlt = NULL;
									pImg->get_alt(&strAlt);
									if( (SUCCEEDED(hr)) && (strAlt) )
									{
										str += _T("\r\n(Alt tag value) ");
										str += strAlt;
										::SysFreeString(strAlt);
									}
								}
								::SysFreeString(strTag);
							}
							pParent->Release();
						}
						pElem->Release();
					}
					
					pImg->Release();
				}
				
			}
		}
		break;
	case CONTEXT_MENU_TABLE:
		{
			str = _T("OnOnContextMenuVbwb1_CCONTEXT_MENU_TABLE");
		}
		break;
	case CONTEXT_MENU_TEXTSELECT:
		{
			//Get the selected TEXT

			//Allow default context menu
			*ctxDisplay = VARIANT_TRUE;
			str = _T("OnOnContextMenuVbwb1_CONTEXT_MENU_TEXTSELECT\r\n(Selection value) ");
			//QI dispatch for HTMLDocument
			hr = ObjElem->QueryInterface(IID_IHTMLElement, 
					reinterpret_cast<void**>(&pElem));
			if( (SUCCEEDED(hr)) && (pElem) )
			{
				//Get the Document dispatch
				hr = pElem->get_document(&pDisp);
				if( (SUCCEEDED(hr)) && (pDisp) )
				{
					IHTMLDocument2 *pDoc = NULL;
					//QI dispatch for object's document
					hr = pDisp->QueryInterface(IID_IHTMLDocument2, 
							reinterpret_cast<void**>(&pDoc));
					if( (SUCCEEDED(hr)) && (pDoc) )
					{
						//Get selection object from document
						IHTMLSelectionObject *pSelectionObj = NULL;
						hr = pDoc->get_selection(&pSelectionObj);
						if( (SUCCEEDED(hr)) && (pSelectionObj) )
						{
							//Get the selection object type
							//We are only interested in Text
							BSTR strType = NULL;
							hr = pSelectionObj->get_type(&strType);
							if( (SUCCEEDED(hr)) && (strType) )
							{
								CString strTemp = strType;
								strTemp.MakeLower();
								if(strTemp == _T("text"))
								{
									IDispatch *pDispR = NULL;
									//Create range
									hr = pSelectionObj->createRange(&pDispR);
									if( (SUCCEEDED(hr)) && (pDispR) )
									{
										//Get the TextRange
										IHTMLTxtRange *pTxtRange = NULL;
										hr = pDispR->QueryInterface(IID_IHTMLTxtRange,
												reinterpret_cast<void**>(&pTxtRange));
										if( (SUCCEEDED(hr)) && (pTxtRange) )
										{
											BSTR strSel = NULL;
											hr = pTxtRange->get_text(&strSel);
											if( (SUCCEEDED(hr)) && (strSel) )
											{
												str += strSel;
												::SysFreeString(strSel);
											}
											pTxtRange->Release();
										}
										pDispR->Release();
									}
								}								
								::SysFreeString(strType);
							}
							pSelectionObj->Release();
						}
						pDoc->Release();
					}
					pDisp->Release();
				}
				pElem->Release();
			}
		}
		break;
	case CONTEXT_MENU_ANCHOR:
		{
			//Get the Href and OuterText (text displayed)
			str = _T("OnOnContextMenuVbwb1_CONTEXT_MENU_ANCHOR\r\n(HREF value) ");
			if(ObjElem)
			{
				//Get the HREF
				hr = ObjElem->QueryInterface(IID_IHTMLAnchorElement, 
						reinterpret_cast<void**>(&pAElem));
				BSTR strTags = NULL;
				if( (SUCCEEDED(hr)) && (pAElem) )
				{
					pAElem->get_href(&strTags);
					if( (SUCCEEDED(hr)) && (strTags) )
					{
						str += strTags;
						::SysFreeString(strTags);
						strTags = NULL;
					}
					pAElem->Release();
				}
				//Get the OuterText
				hr = ObjElem->QueryInterface(IID_IHTMLElement, 
						reinterpret_cast<void**>(&pElem));
				if( (SUCCEEDED(hr)) && (pElem) )
				{
					pElem->get_outerText(&strTags);
					if( (SUCCEEDED(hr)) && (strTags) )
					{
						str += _T("\r\n(OuterText value) ");
						str += strTags;
						::SysFreeString(strTags);
					}
					pElem->Release();
				}
			}
		}
		break;
	case CONTEXT_MENU_UNKNOWN:
		{
			str = _T("OnOnContextMenuVbwb1_CONTEXT_MENU_UNKNOWN");
		}
		break;
	case CONTEXT_MENU_IMGDYNSRC:
		{
			str = _T("OnOnContextMenuVbwb1_CONTEXT_MENU_IMGDYNSRC");
		}
		break;
	case CONTEXT_MENU_IMGART:
		{
			str = _T("OnOnContextMenuVbwb1_CONTEXT_MENU_IMGART");
		}
		break;
	case CONTEXT_MENU_DEBUG:
		{
			str = _T("OnOnContextMenuVbwb1_CONTEXT_MENU_DEBUG");
		}
		break;
	case CONTEXT_MENU_VSCROLL:
		{
			*ctxDisplay = VARIANT_TRUE; //Allow
			str = _T("OnOnContextMenuVbwb1_CONTEXT_MENU_VSCROLL");
		}
		break;
	case CONTEXT_MENU_HSCROLL:
		{
			*ctxDisplay = VARIANT_TRUE;
			str = _T("OnOnContextMenuVbwb1_CONTEXT_MENU_HSCROLL");
		}
		break;
	default:
		{
			*ctxDisplay = VARIANT_TRUE;
			str = _T("OnOnContextMenuVbwb1_default");
		}
	}
	Log(str);
}

/*
Using this event incorrectly can compromise the security of your application.
*/
//default value of Cancel = VARIANT_TRUE
void CMFCDemoDlg::OnOnHTTPSecurityProblemVbwb1(short wbUID, long lProblem, BOOL FAR* Cancel) 
{
//Possible problems:
//ERROR_INTERNET_HTTP_TO_HTTPS_ON_REDIR
//ERROR_INTERNET_HTTPS_TO_HTTP_ON_REDIR
//...

	TCHAR tmp[50];
	#ifdef UNICODE
		_ltow(lProblem, tmp, 10);
	#else
		_ltoa(lProblem, tmp, 10);
	#endif
	CString strTmp(_T("Security problem #"));
	strTmp += tmp;
	strTmp += _T(". Proceed?");
	if( MessageBox(strTmp, _T("HTTP Security Confirmation"), MB_YESNO | MB_ICONWARNING) == IDYES)
	{
		*Cancel = VARIANT_FALSE;
	}
}

//Fires after OnBeforeNaviate2
void CMFCDemoDlg::OnProtocolHandlerOnBeginTransactionVbwb1(short wbUID, LPCTSTR sURL, LPCTSTR sRequestHeaders, BSTR FAR* sAdditionalHeaders, BOOL FAR* Cancel) 
{
	CString str(_T("\r\n(OnProtocolHandlerOnBeginTransactionVbwb1)\r\n(URL) "));
	str += sURL;
	str += _T("\r\n(RequestHeaders)\r\n");
	str += sRequestHeaders;
	Log(str);
}

//Fires before OnDocumentComplete
void CMFCDemoDlg::OnProtocolHandlerOnResponseVbwb1(short wbUID, LPCTSTR sURL, LPCTSTR sResponseHeaders, LPCTSTR sRedirectedUrl, LPCTSTR sRedirectHeaders, BOOL FAR* Cancel) 
{
	CString str(_T("\r\n(OnProtocolHandlerOnResponseVbwb1)\r\n(URL) "));
	str += sURL;
	str += _T("\r\n(ResponseHeaders)");
	str += sResponseHeaders;
	str += _T("(Redirected URL) ");
	str += sRedirectedUrl;
	str += _T("\r\n(RedirectHeaders)\r\n");
	str += sRedirectHeaders;
	Log(str);	
}

/*
Fired before an HTML message is about to be displayed.
Can change the message or stop displaying message.
No need to set the Silent property of WB to True to stop these msgs.
Default ShowMsg = VARIANT_FALSE
Sample:
Your current security settings prohibit running ActiveX controls on this page. As a result, the page may not display correctly.
*/
void CMFCDemoDlg::OnShowMessageVbwb1(short wbUID, BSTR FAR* sMsg, BOOL FAR* ShowMsg) 
{
	*ShowMsg = VARIANT_TRUE;
}

//StatusCode, one of HTTP_STATUS_XXX enums
void CMFCDemoDlg::OnNavigateErrorVbwb1(short wbUID, LPDISPATCH pDisp, VARIANT FAR* URL, VARIANT FAR* TargetFrameName, VARIANT FAR* StatusCode, BOOL FAR* Cancel) 
{
	if( StatusCode->vt == VT_I4 ) //LONG
	{
		switch (StatusCode->lVal)
		{
		case HTTP_STATUS_CONTINUE:
		case HTTP_STATUS_ACCEPTED:
		case HTTP_STATUS_OK:
		case HTTP_STATUS_REDIRECT:
		case HTTP_STATUS_REQUEST_TIMEOUT: //Allow default timeout page to display
			{
				*Cancel = VARIANT_FALSE;
			}
			break;
		default:
			{
				TCHAR tmp[50];
				#ifdef UNICODE
					_ltow(StatusCode->lVal, tmp, 10);
				#else
					_ltoa(StatusCode->lVal, tmp, 10);
				#endif
				CString strTmp(_T("Navigation Error #"));
				strTmp += tmp;
				strTmp += _T(". Procceed?");
				if( MessageBox(strTmp, _T("Navigate Error Confirmation"), MB_YESNO | MB_ICONWARNING) == IDYES)
				{
					*Cancel = VARIANT_FALSE;
				}
			}
		}
	}
	
}

void CMFCDemoDlg::OnOnAuthenticationVbwb1(short wbUID, BSTR FAR* sUsername, BSTR FAR* sPassword, BOOL FAR* Cancel) 
{
//Please take a look at OnFileDownloadExVbwb1 event for an example of how to
//set up sUsername and sPassword with values obtained from user, ...
	*Cancel = VARIANT_TRUE;
}

//Fires to notify client of file download errors
void CMFCDemoDlg::OnOnFileDLDownloadErrorVbwb1(short FileDlUID, LPCTSTR sURL, LPCTSTR sErrorMsg) 
{
	CString str(_T("OnOnFileDLDownloadErrorVbwb1\r\n(URL) "));
	str += sURL;
	str += _T("\r\n(Error Msg) ");
	str += sErrorMsg;
	Log(str);
}

//Activate protocol handlers to intercept headers
void CMFCDemoDlg::OnChkhttpprotocols() 
{
	try
	{
		if(IsDlgButtonChecked(IDC_CHKHTTPPROTOCOLS) == BST_CHECKED)
		{
			m_WBctl.RegisterHTTPprotocol(VARIANT_TRUE);
			m_WBctl.RegisterHTTPSprotocol(VARIANT_TRUE);
			SetDlgItemText(IDC_CHKHTTPPROTOCOLS, _T("Click to stop diaplay of HTTP+HTTPS Headers"));
		}
		else
		{
			m_WBctl.RegisterHTTPprotocol(VARIANT_FALSE);
			m_WBctl.RegisterHTTPSprotocol(VARIANT_FALSE);
			SetDlgItemText(IDC_CHKHTTPPROTOCOLS, _T("Click to dispaly HTTP+HTTPS Headers"));
		}
	}
	catch(...)
	{
	}
}

//Open URL in sandbox
void CMFCDemoDlg::OnBtnsandbox() 
{
	LPTSTR surl = new char[255];
	surl[254] = '\0';
	if(surl)
	{
		m_Url.GetWindowText(surl,254);
		if(!m_SandBoxDlg.IsWindowVisible())
			m_SandBoxDlg.ShowWindow(TRUE);
		else
			m_SandBoxDlg.SetActiveWindow();
		m_SandBoxDlg.m_SandBoxWB.NavigateSimple(m_SandBoxDlg.m_CurSandBox, surl);
		delete[] surl;
	}
}

//A tab was selected, bring the coresponding WB to front of the stack
void CMFCDemoDlg::OnSelchangeWbTabs(NMHDR* pNMHDR, LRESULT* pResult) 
{
	int isel = m_wbtabs.GetCurSel();
	if(isel > -1)
	{
		TCITEM pitem;
		pitem.mask = TCIF_PARAM;
		if(m_wbtabs.GetItem( isel, &pitem) )
		{
			//Get the lParam which is the value of m_CurWB
			//we stored during a call to insert after a call
			//to AddBrowser method of vbMHWB control
			short stab = (short)pitem.lParam;
			if(stab > 0)
			{
				m_CurWB = stab;
				//Place this one on top of the stack
				m_WBctl.PlaceWBOnTop(m_CurWB);
				//Set focus
				m_WBctl.SetFocusW(m_CurWB);
				//Bring back and forward btns into synch
				GetDlgItem(IDC_BACK_BTN)->EnableWindow((BOOL)m_BackBtns[m_CurWB - 1]);
				GetDlgItem(IDC_FORWARD_BTN)->EnableWindow((BOOL)m_ForwardBtns[m_CurWB - 1]);
			}
		}
	}
	*pResult = 0;
}

void CMFCDemoDlg::OnBackBtn() 
{
	if(m_CurWB > 0)
	{
		m_WBctl.GoBack(m_CurWB);
	}
}

void CMFCDemoDlg::OnStopBtn() 
{
	if(m_CurWB > 0)
	{
		m_WBctl.Stop(m_CurWB);
	}
	
}

void CMFCDemoDlg::OnForwardBtn() 
{
	if(m_CurWB > 0)
	{
		m_WBctl.GoForward(m_CurWB);
	}	
}

void CMFCDemoDlg::OnCommandStateChangeVbwb1(short wbUID, long Command, BOOL Enable) 
{
	DWORD dwCommand = (DWORD)Command;
	if(dwCommand == CSC_NAVIGATEBACK)
	{
		m_BackBtns[wbUID - 1] = (Enable) ? 1 : 0;
		//Update btns state only for the current Webbrowser
		if(wbUID == m_CurWB)
			GetDlgItem(IDC_BACK_BTN)->EnableWindow((BOOL)Enable);
	}
	else if(dwCommand == CSC_NAVIGATEFORWARD)
	{
		m_ForwardBtns[wbUID - 1] = (Enable) ? 1 : 0;
		if(wbUID == m_CurWB)
			GetDlgItem(IDC_FORWARD_BTN)->EnableWindow((BOOL)Enable);
	}
}

void CMFCDemoDlg::OnBtnthumbnails() 
{
	int lwbcount = m_wbtabs.GetItemCount();
	if(lwbcount == 0 )
	{
		MessageBox(_T("No browsers to render???"));
		return;
	}
	//For demo purposes, I am just using the dialog itself
	//to draw the thumbnails. You normally would want to use
	//an offscreen hDC to manage these thumbs.
	//And due to lack of realstate,
	//no more than three thumbs can be displayed 120x120
	HDC hDc = ::GetDC(GetSafeHwnd());
	short swb = 0;
	RECT ldlg;
	RECT lrect;
	GetWindowRect(&ldlg);
	GetDlgItem(IDC_BTNTHUMBNAILS)->GetWindowRect(&lrect);
	lrect.left -= ldlg.left;
	lrect.top -= ldlg.top;
	lrect.top += 5;
	if(hDc)
	{
		//Go through the tabs and extract the wbUID
		//from the lparam of each tab item
		for(int i = 0; i < lwbcount; i++)
		{
			TCITEM pitem;
			pitem.mask = TCIF_PARAM;
			if(m_wbtabs.GetItem( i, &pitem) )
			{
				//Get the lParam which is the value of wbUID that
				//we stored during a call to insert after a call
				//to AddBrowser method of vbMHWB control
				swb = (short)pitem.lParam;
				if(swb > 0)
				{
					try
					{
						m_WBctl.DrawWBThumbnailOnWnd(swb, (long)hDc, lrect.left , 
											lrect.top, 120, 120);
					}
					catch(...)
					{
					}
				}
			}
			lrect.top += 125; //Next snapshot
		}
	}
}

void CMFCDemoDlg::OnButtonzoom() 
{

	int isel = m_Zoom.GetCurSel();
	if((int)(m_WBctl.GetWBPageTextSize(m_CurWB)) == isel)
	{
		MessageBox(_T("Already zoomed with the requsted value"));
		return;
	}
	m_WBctl.SetWBPageTextSize(m_CurWB, (long)isel);

}

void CMFCDemoDlg::OnBtnSaveasbitmap() 
{
	if(m_CurWB > 0)
	{
		m_WBctl.SaveAsBitmap(m_CurWB, _T("C:\\vbMHWB_MfcDemoDlg_testbmp.bmp"));
	}
}

void CMFCDemoDlg::OnBtnPostdata() 
{
	//Use POST or GET, optional
	//If ? present then GET must be used
	//else POST raw data
	short iiD = 0;

	//POST
	//abstractvb supports post
	m_WBctl.WBPostData(_T("http://abstractvb.com/search.asp"), 
				   _T("SEARCHSTRING=VB.NET&SEARCHTYPE=CODE"), &iiD);

	//GET
	//google search supports GET
	//http://www.google.ca/search
	//?
	//hl=en&q=sea&btnG=Google+Search&meta=
	//m_WBctl.WBPostData _T("http://www.google.ca/search?hl=en&q=sea&btnG=Google+Search&meta="), NULL, &iiD
}

///////////////////////////
//OnPost Evenets
///////////////////////////

void CMFCDemoDlg::OnOnPostResponseVbwb1(short PostUID, LPCTSTR sURL, long lResponseCode, LPCTSTR sResponseHeaders) 
{
	CString str(_T("OnOnPostResponseVbwb1>>>"));
	str += _T("\r\nsResponseHeaders");
	if(sResponseHeaders)
		str += sResponseHeaders;
	Log(str);
}

void CMFCDemoDlg::OnOnPostOnProgressVbwb1(short PostUID, LPCTSTR sURL, long lProgress, long lProgressMax, long lStatusCode, LPCTSTR sStatusText, BOOL FAR* CancelPost) 
{
	CString str(_T("OnOnPostOnProgressVbwb1>>> "));
	Log(str);
}

void CMFCDemoDlg::OnOnPostErrorVbwb1(short PostUID, LPCTSTR sURL, LPCTSTR sErrorMsg) 
{
	CString str(_T("OnOnPostErrorVbwb1>>> "));
	str += _T("\r\nsErrorMsg");
	if(sErrorMsg)
		str += sErrorMsg;
	Log(str);
}

void CMFCDemoDlg::OnOnPostEndVbwb1(short PostUID, LPCTSTR sURL) 
{
	CString str(_T("OnOnPostEndVbwb1>>> "));
	Log(str);
}

void CMFCDemoDlg::OnOnPostDataAvailableVbwb1(short PostUID, LPCTSTR sURL, LPCTSTR pData, BOOL FAR* CancelPost) 
{
	CString str(_T("OnOnPostDataAvailableVbwb1>>>"));
	str += _T("\r\n========pData Chunk Start========\r\n");
	if(pData)
		str += pData;
	str += _T("\r\n========pData Chunk End========\r\n");
	Log(str);
}


///////////////////////////////////////////////
//DragDrop Events
//Default value for lEffect = DROPEFFECT_COPY
//////////////////////////////////////////////

void CMFCDemoDlg::OnOnWBDragEnterVbwb1(short wbUID, short KeyState, long ptX, long ptY, long FAR* lEffect) 
{
	//Start any visual effects
	Log(_T("OnOnWBDragEnterVbwb1>>> "));
}

void CMFCDemoDlg::OnOnWBDragLeaveVbwb1(short wbUID) 
{
	//Cancel any visual aid stuff
	Log(_T("OnOnWBDragLeaveVbwb1>>> "));
}

void CMFCDemoDlg::OnOnWBDragOverVbwb1(short wbUID, short KeyState, long ptX, long ptY, long FAR* lEffect) 
{
	//Find the elem under the mouse to make a drop more intelligent
	//Log(_T("OnOnWBDragOverVbwb1>>> "));
}

//Multiple
//from explorer?
//vData: SafeArray of BSTRs
void CMFCDemoDlg::OnOnWBDrop2Vbwb1(short wbUID, short KeyState, long ptX, long ptY, VARIANT FAR* vData, long FAR* lEffect) 
{
	CString str(_T("OnOnWBDrop2Vbwb1>>> "));
	SAFEARRAY * psa = vData->parray;
	if(psa)
	{
		//get the bounds always one dimentional)
		unsigned long elems = psa->cbElements;
		if(elems == 0)
			return;
		BSTR HUGEP *pbstr;
		HRESULT hr = SafeArrayAccessData(psa, (void **)&pbstr);
		for(ULONG x = 0; x < elems; x++)
		{
			str += pbstr[x];
			strLog += _T("\r\n");
		}
		SafeArrayUnaccessData(psa);
	}
	Log(str);
}

void CMFCDemoDlg::OnOnFileDLResponseVbwb1(short FileDlUID, LPCTSTR sURL, long lResponseCode, LPCTSTR sResponseHeaders, BOOL FAR* CancelDl) 
{
	if(lResponseCode == 301 || lResponseCode > 399)
	{
		TCHAR tmp[50];
		#ifdef UNICODE
			_ltow(lResponseCode, tmp, 10);
		#else
			_ltoa(lResponseCode, tmp, 10);
		#endif
		CString strTmp(_T("Errors occured while downloading. Response Code #"));
		strTmp += tmp;
		MessageBox(strTmp, _T("File Download Response Error"), MB_OK | MB_ICONERROR);
		*CancelDl = VARIANT_TRUE;
	}
	
}

//Default, Cancel = VARIANT_TRUE
//Only for XP IE 6 sp2 and higher
void CMFCDemoDlg::OnNewWindow3Vbwb1(short wbUID, LPDISPATCH FAR* ppDisp, BOOL FAR* Cancel, long lFlags, LPCTSTR sURLContext, LPCTSTR sURL) 
{
	//Here we have the URL up front, so we can examin it,..
	//if(sURL)
	if(ppDisp)
	{
		//Allow it
		*Cancel = VARIANT_FALSE;
		if(!m_SandBoxDlg.IsWindowVisible())
			m_SandBoxDlg.ShowWindow(TRUE);
		else
			m_SandBoxDlg.SetActiveWindow();
		//We display this in our sandbox
		*ppDisp = m_SandBoxDlg.m_SandBoxWB.GetDocument(wbUID);
	}
}

//Default, Cancel = VARIANT_TRUE
void CMFCDemoDlg::OnNewWindow2Vbwb1(short wbUID, LPDISPATCH FAR* ppDisp, BOOL FAR* Cancel) 
{
	if(MessageBox(_T("Proceed to open new window?"), _T("NewWindow2"), 
			MB_YESNO | MB_ICONQUESTION) == IDYES )
	{
		if(ppDisp)
		{
			//Allow it
			*Cancel = VARIANT_FALSE;
			if(!m_SandBoxDlg.IsWindowVisible())
				m_SandBoxDlg.ShowWindow(TRUE);
			else
				m_SandBoxDlg.SetActiveWindow();
			//We display this in our sandbox
			*ppDisp = m_SandBoxDlg.m_SandBoxWB.GetDocument(wbUID);
		}
	}
}

/*
MSDN:
GetOptionKeyPath and GetOverrideKeyPath Compared
You probably don't see any difference between IDocHostUIHandler::GetOptionKeyPath and
IDocHostUIHandler2::GetOverrideKeyPath. The difference between them is subtle, but 
significant. If you implement IDocHostUIHandler::GetOptionKeyPath, your WebBrowser 
Control instance will ignore any user settings for Internet Explorer. These settings 
are stored in the registry under HKEY_CURRENT_USER/Software/Microsoft/Internet Explorer. 
If you implement IDocHostUIHandler2::GetOverrideKeyPath, your WebBrowser Control instance 
will incorporate any user settings font settings, menu extensions, and so forth into the 
way it displays and behaves.

To illustrate the difference between IDocHostUIHandler::GetOptionKeyPath and 
IDocHostUIHandler2::GetOverrideKeyPath, let's take a look again at the code example 
for the section on IDocHostUIHandler::ShowContextMenu. Remember the line:

spCT->Exec(&CGID_ShellDocView, SHDVID_ADDMENUEXTENSIONS, 0, &var1, &var2);

If you've implemented IDocHostUIHandler::GetOptionKeyPath, this line would add no 
menu items to the shortcut menu because menu extension information is stored in 
the registry for the current user. If you've implemented 
IDocHostUIHandler2::GetOverrideKeyPath, this line would add any extensions 
defined for the current user under 
HKEY_CURRENT_USER/Software/Microsoft/Internet Explorer/MenuExt, 
unless you explicitly supply an empty or alternative MenuExt key in 
your custom registry key.
*/
void CMFCDemoDlg::OnOnGetOptionKeyPathVbwb1(short wbUID, BSTR FAR* sRegistryOptionKeyPath) 
{
	Log(_T("OnOnGetOptionKeyPathVbwb1>>> "));
}

void CMFCDemoDlg::OnOnGetOverrideKeyPathVbwb1(short wbUID, BSTR FAR* sRegistryOverrideKeyPath) 
{
	Log(_T("OnOnGetOverrideKeyPathVbwb1>>> "));
}



void CMFCDemoDlg::OnOnWBDropVbwb1(short wbUID, short KeyState, long ptX, long ptY, LPCTSTR lpData, long lWBDropFormat, long FAR* lEffect) 
{
//Single drop
//lWBDropFormat can be one of
//	typedef enum WB_DROP_FORMATS
//	{
//		WB_CFHTML			= 0,
//		WB_CFTEXT			= 1,
//		WB_CFSINGLEFILE		= 2,
//		WB_CFRTF			= 3,
//		WB_CFERROR			= 4
//	}WB_DROP_FORMATS;
/**/
	CString str(_T("OnOnWBDropVbwb1>>> "));
	switch (lWBDropFormat)
	{
	case 0:
		{
			str += _T("CFHTML - \r\n");
		}
		break;
	case 1:
		{
			str += _T("CFTEXT - \r\n");
		}
		break;
	case 2:
		{
			str += _T("CFSINGLEFILE - \r\n");
		}
		break;
	case 3:
		{
			str += _T("RTF - \r\n");
		}
		break;
	case 4:
		{
			str += _T("CFHTML - Error");
		}
		break;
	}
	if(lpData)
	{
		str += lpData;
		//Sample use
		//crack the URL to make sure it is valid and do other checks....
		//m_WBctl.NavigateSimple(wbUID, lpData);
	}
	Log(str);
	
}

//To receive this event in place of DocumentComplete, set SourceOnDocComplete
//property to VARIANT_TRUE
void CMFCDemoDlg::OnDocumentCompleteWBExVbwb1(short wbUID, VARIANT FAR* URL, LPDISPATCH pDisp, BOOL isTopLevel, LPCTSTR sDocSource) 
{
	if( isTopLevel)
	{
		CString str(_T("OnDocumentCompleteWBExVbwb1 <<<TopLevel>>> "));
		if(URL->vt == VT_BSTR)
			str += URL->bstrVal;

		str += _T("\r\n");
		str += sDocSource;
		Log(str);
		m_WBctl.SetFocusW(wbUID);
	}
	else
	{
		CString stra(_T("OnDocumentCompleteWBExVbwb1>>> "));
		if(URL->vt == VT_BSTR)
			stra += URL->bstrVal;

		stra += _T("\r\n");
		stra += sDocSource;
		Log(stra);
	}
}

//To intercept the source of the document using DocumentCompleteWBEx event
//before any scripts are executed, set SourceOnDocComplete property to true
void CMFCDemoDlg::OnChksource() 
{
	//
	if(IsDlgButtonChecked(IDC_CHKSOURCE) == BST_CHECKED)
	{
		m_WBctl.SetSourceOnDocComplete(m_CurWB, VARIANT_TRUE);
	}
	else
	{
		m_WBctl.SetSourceOnDocComplete(m_CurWB, VARIANT_FALSE);
	}
}

/*
The current list of URLACTION that will not be passed to the custom security manager
in most circumstances by Internet Explorer 5 are:
	URLACTION_SHELL_FILE_DOWNLOAD 
	URLACTION_COOKIES 
	URLACTION_JAVA_PERMISSIONS 
	URLACTION_SCRIPT_PASTE 
There is no workaround for this problem. The behavior for the URLACTION can only be
changed for all browser clients on the system by altering the security zone settings
from Internet Options.
*/

/*
Default value of bHandled = false
PUAF, one of PUAF enum (MSDN)
*/
void CMFCDemoDlg::OnWBProcessUrlActionVbwb1(short wbUID, LPCTSTR sURL, long lUrlAction, long PUAF_Flag, long FAR* lpUrlPolicy, BOOL FAR* bHandled) 
{
/*
To have your own policy take effect based on a lUrlAction
Set lpUrlPolicy to desiered URLPOLICY_ flag (Allow/disallow/...)
Set bHandled to VARIANT_TRUE
*/	
}


//DEL 	CString str(_T("OnWBProcessUrlActionVbwb1\r\n(URL) "));
//DEL 	str += sURL;
//DEL     if( (lUrlAction == URLACTION_SCRIPT_OVERRIDE_SAFETY) ||
//DEL         (lUrlAction == URLACTION_ACTIVEX_OVERRIDE_SCRIPT_SAFETY) ||
//DEL         (lUrlAction == URLACTION_ACTIVEX_OVERRIDE_DATA_SAFETY) ||
//DEL         (lUrlAction == URLACTION_ACTIVEX_OVERRIDE_OBJECT_SAFETY) )
//DEL //    To stop form submissions to. Hits before URLACTION_HTML_SUBMIT_FORMS_FROM
//DEL //    If cancelled at this point then URLACTION_HTML_SUBMIT_FORMS_FROM will not hit
//DEL     else if( lUrlAction == URLACTION_HTML_SUBMIT_FORMS_TO )
//DEL 	{
//DEL         str += "\r\nURLACTION_HTML_SUBMIT_FORMS_TO";
//DEL 	}
//DEL     else if( lUrlAction == URLACTION_HTML_SUBMIT_FORMS_FROM )
//DEL 	{
//DEL         str += _T("\r\nURLACTION_HTML_SUBMIT_FORMS_FROM");
//DEL 	}
//DEL //    Stop running all scripts. hits numerious times
//DEL     else if( lUrlAction == URLACTION_SCRIPT_RUN )
//DEL 	{
//DEL         str += _T("\r\nURLACTION_SCRIPT_RUN");
//DEL 	}
//DEL //    Stop running activex controls
//DEL     else if( lUrlAction == URLACTION_ACTIVEX_RUN )
//DEL 	{
//DEL         str += _T("\r\nURLACTION_ACTIVEX_RUN");
//DEL 	}
//DEL     else
//DEL         str += _T("\r\nElse");
//DEL 	Log(str);