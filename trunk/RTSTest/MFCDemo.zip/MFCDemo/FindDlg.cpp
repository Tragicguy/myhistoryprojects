// FindDlg.cpp : implementation file
//

#include "stdafx.h"
#include "MFCDemo.h"
#include "FindDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CFindDlg dialog


CFindDlg::CFindDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CFindDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CFindDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void CFindDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CFindDlg)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CFindDlg, CDialog)
	//{{AFX_MSG_MAP(CFindDlg)
	ON_WM_CLOSE()
	ON_BN_CLICKED(IDC_BTNFIND, OnBtnfind)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CFindDlg message handlers

void CFindDlg::OnClose() 
{	
	//CDialog::OnClose();
	//Just hide it, we destroy this wnd in DemoDlg OnClose event
	ShowWindow(FALSE);
}

void CFindDlg::OnBtnfind() 
{
	//Reset all
	m_strFind.Empty();
	m_strColor.Empty();
	m_bDownWard = VARIANT_TRUE;
	m_bHighLight = FALSE;
	m_bMatchWholeWord = VARIANT_FALSE;
	m_bMatchCase = VARIANT_FALSE;
	
	//Set up find variables
	GetDlgItemText(IDC_TXTFIND,m_strFind);
	GetDlgItemText(IDC_COMBFIND_COLORS, m_strColor);

	if(IsDlgButtonChecked(IDC_CHKFIND_HIGHLIGHT) == BST_CHECKED)
		m_bHighLight = TRUE;

	if(IsDlgButtonChecked(IDC_CHKFIND_MATCHWWORDS) == BST_CHECKED)
		m_bMatchWholeWord = VARIANT_TRUE;

	if(IsDlgButtonChecked(IDC_CHKFIND_MATCHCASE) == BST_CHECKED)
		m_bMatchCase = VARIANT_TRUE;

	if(IsDlgButtonChecked(IDC_RDFIND_UPWARD) == BST_CHECKED)
		m_bDownWard = VARIANT_FALSE;
	
	//Post message to DemoDlg (parent)
	//Simple Dlg->Dlg communication
	::PostMessage(GetParent()->GetSafeHwnd(),UWM_FINDTEXT, 0, 0);
}
